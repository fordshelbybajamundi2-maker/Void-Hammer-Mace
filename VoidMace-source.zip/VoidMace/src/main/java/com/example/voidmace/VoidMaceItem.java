package com.example.voidmace;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

public final class VoidMaceItem extends Item {
    public VoidMaceItem(Settings settings) { super(settings); }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack held = user.getStackInHand(hand);
        if (!world.isClient) {
            VoidMaceProjectile projectile = new VoidMaceProjectile(world, user, held.copy());
            projectile.setVelocity(user, user.getPitch(), user.getYaw(), 0.0F, 1.8F, 0.4F);
            world.spawnEntity(projectile);
            if (!user.getAbilities().creativeMode) held.decrement(1);
        }
        user.getItemCooldownManager().set(this, 12);
        return TypedActionResult.success(held, world.isClient());
    }
}

package com.example.voidmace;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class VoidMaceMod implements ModInitializer {
    public static final String MOD_ID = "voidmace";
    public static final Item VOID_MACE = Registry.register(
            Registries.ITEM, Identifier.of(MOD_ID, "void_mace"),
            new VoidMaceItem(new Item.Settings().maxCount(1).maxDamage(250)));
    public static final EntityType<VoidMaceProjectile> VOID_MACE_PROJECTILE = Registry.register(
            Registries.ENTITY_TYPE, Identifier.of(MOD_ID, "void_mace_projectile"),
            EntityType.Builder.<VoidMaceProjectile>create(VoidMaceProjectile::new, SpawnGroup.MISC)
                    .dimensions(0.65F, 0.65F).maxTrackingRange(8).trackingTickInterval(10)
                    .build("voidmace:void_mace_projectile"));

    @Override
    public void onInitialize() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(entries -> entries.add(VOID_MACE));
    }
}

package com.example.voidmace;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.thrown.ThrownItemEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.UUID;

public final class VoidMaceProjectile extends ThrownItemEntity {
    private ItemStack returnStack = new ItemStack(VoidMaceMod.VOID_MACE);
    private UUID lastPlayerHit;
    private UUID ownerId;
    private boolean returned;

    public VoidMaceProjectile(EntityType<? extends VoidMaceProjectile> type, World world) {
        super(type, world);
    }

    public VoidMaceProjectile(World world, LivingEntity owner, ItemStack stack) {
        super(VoidMaceMod.VOID_MACE_PROJECTILE, owner, world);
        this.ownerId = owner.getUuid();
        this.returnStack = stack.copyWithCount(1);
    }

    @Override protected Item getDefaultItem() { return VoidMaceMod.VOID_MACE; }

    @Override
    protected void onEntityHit(EntityHitResult hit) {
        Entity target = hit.getEntity();
        if (target instanceof PlayerEntity player && !player.getUuid().equals(ownerId)) {
            lastPlayerHit = player.getUuid();
            // The mace is a utility projectile: it records the hit and continues without damage.
        }
    }

    @Override
    protected void onBlockHit(BlockHitResult hit) {
        super.onBlockHit(hit);
        finishThrow(hit.getPos());
    }

    @Override
    protected void onCollision(HitResult hit) {
        if (hit.getType() == HitResult.Type.BLOCK) {
            onBlockHit((BlockHitResult) hit);
        } else if (hit.getType() == HitResult.Type.MISS && age > 200) {
            finishThrow(getPos());
        }
    }

    @Override
    public boolean canHit(Entity entity) {
        if (entity.getUuid().equals(ownerId)) return false;
        return super.canHit(entity);
    }

    private void finishThrow(Vec3d landing) {
        if (returned || getWorld().isClient) return;
        returned = true;
        if (lastPlayerHit != null && getWorld() instanceof ServerWorld serverWorld) {
            Entity found = serverWorld.getEntity(lastPlayerHit);
            if (found instanceof ServerPlayerEntity target && target.isAlive()) {
                BlockPos safe = BlockPos.ofFloored(landing);
                // Prefer a safe air block at/above the landing point.
                while (safe.getY() < serverWorld.getTopY() - 2 &&
                        (!serverWorld.getBlockState(safe).isAir() || !serverWorld.getBlockState(safe.up()).isAir())) {
                    safe = safe.up();
                }
                target.teleport(serverWorld, safe.getX() + 0.5, safe.getY(), safe.getZ() + 0.5,
                        java.util.Set.of(), target.getYaw(), target.getPitch(), true);
                target.getWorld().sendEntityStatus(target, (byte) 46);
            }
        }
        Entity owner = ownerId == null ? null : getWorld().getPlayerByUuid(ownerId);
        if (owner instanceof PlayerEntity player && player.isAlive()) {
            ItemStack stack = returnStack.isEmpty() ? new ItemStack(VoidMaceMod.VOID_MACE) : returnStack.copyWithCount(1);
            if (!player.getInventory().insertStack(stack)) {
                player.dropItem(stack, false);
            }
        } else {
            // If the owner is offline/dead, leave the item where the throw ended rather than deleting it.
            getWorld().spawnEntity(new net.minecraft.entity.ItemEntity(getWorld(), landing.x, landing.y, landing.z,
                    returnStack.isEmpty() ? new ItemStack(VoidMaceMod.VOID_MACE) : returnStack.copyWithCount(1)));
        }
        discard();
    }
}

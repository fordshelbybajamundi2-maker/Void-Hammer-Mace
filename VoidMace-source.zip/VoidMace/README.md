# Void Mace (Fabric 1.21.1)

A starter Fabric mod project for Minecraft Java Edition 1.21.1. Right-click with the Void Mace to throw it. The projectile records the most recent non-owner player it hits, teleports that player to its block-impact location when it lands, and returns the mace to the owner's inventory (dropping it if the inventory is full).

## Phone-only build option (GitHub Actions)

You do **not** need to install JDK or Gradle on your Android phone if you use the included GitHub Actions workflow. GitHub's hosted runner installs Java 21 and builds the project in the cloud.

1. Sign in or create an account at GitHub.
2. Create a new repository. For a personal project, a private repository is fine.
3. Upload the contents of this project, including the `.github/workflows/build.yml` file and all source/build files. Keep the `.github` folder and its `workflows` subfolder; if the GitHub mobile upload UI hides dot-folders, use GitHub in your browser with desktop-site mode or upload the files through the repository's web UI.
4. Open the repository's **Actions** tab and select **Build Void Mace**. If prompted, enable Actions.
5. Wait for the run to finish. A green check means the build job succeeded; open the run and download the `voidmace-fabric-1.21.1` artifact.
6. Extract the downloaded artifact ZIP. Put the actual `voidmace-1.0.0.jar` (not the artifact ZIP) in the `mods` folder used by your Zalith Launcher instance.

A push to the repository also starts the workflow automatically.

## Requirements to play
- Minecraft Java Edition **1.21.1** (this project does not target every 1.21.x patch)
- Fabric Loader compatible with 1.21.1
- Fabric API for 1.21.1

## Build locally (optional)
- JDK 21
- Gradle and internet access for dependency downloads
- Run `gradle build`; the output should be in `build/libs/`.

## Give yourself the item
In a world where commands are enabled, run:

```mcfunction
/give @p voidmace:void_mace
```

## Notes
- The item uses the vanilla mace texture as a placeholder; custom purple/void art can be added later.
- This source project has not been verified in a live Minecraft session. If the workflow fails, inspect the build log in the Actions run; the project may need code adjustments before a usable JAR can be produced.
